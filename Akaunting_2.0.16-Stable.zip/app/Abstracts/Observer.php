<?php

namespace App\Abstracts;

use Monooso\Unobserve\CanMute;

abstract class Observer
{
    use CanMute;
}
